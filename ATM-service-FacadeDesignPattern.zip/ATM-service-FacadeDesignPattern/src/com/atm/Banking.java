package com.atm;

public interface Banking
{
    void deposite(double amount);
    void withdraw(double amount);
    void getPreviousTransaction();
}
