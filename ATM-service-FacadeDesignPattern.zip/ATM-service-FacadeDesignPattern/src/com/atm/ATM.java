package com.atm;

public class ATM
{
    public static void main(String[] args)
    {
        User user=new User();
        user.menu();

    }
}
